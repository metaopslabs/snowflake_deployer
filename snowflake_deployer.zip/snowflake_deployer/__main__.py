import sys
import argparse
from snowflake_deploy import snowflake_deploy
from snowflake_import import snowflake_import

def main(argv=sys.argv):
    parser = argparse.ArgumentParser(prog = 'snowflake_deployer', description = 'Deploy state based yaml config to Snowflake. Full readme at https://github.com/metaopslabs/snowflake_deployer', formatter_class = argparse.RawTextHelpFormatter)
    subcommands = parser.add_subparsers(dest='subcommand')

    # Command Line Parameters
    parser.add_argument("-u", "--SNOWFLAKE_USERNAME", default='', help="Snowflake Username")
    parser.add_argument("-a", "--SNOWFLAKE_ACCOUNT", default='', help="Snowflake Account (<identifier>.<region>.<name>)")
    parser.add_argument("-w", "--SNOWFLAKE_WAREHOUSE", default='', help="Snowflake Warehouse for deployments")
    parser.add_argument("-r", "--SNOWFLAKE_ROLE", default='', help="Snowflake Role for username connection")
    parser.add_argument("-c", "--CONFIG_PATH", default='', help="File path to the deployment config file (can vary by environment)")
    
    # Add sub commands
    parser_deploy = subcommands.add_parser("deploy", description="Deployment to Snowflake")
    parser_import = subcommands.add_parser('import', description="Reverse Engineer from Snowflake to YAML config.")

    # Store passed in values
    args = vars(parser.parse_args())
    subcommand = parser.parse_args().subcommand.upper()

    # Checks
    if subcommand is None:
        raise Exception('Missing deployer command.  Must call via "snowflake_deployer [deploy/import]" command. See documentation for further details.')
    elif subcommand.upper() not in ('DEPLOY','IMPORT'):
        raise Exception('Invalid deployer command.  Must call via "snowflake_deployer [deploy/import]" command. See documentation for further details.')
    
    if subcommand == 'DEPLOY':
        snowflake_deploy(args)
    elif subcommand == 'IMPORT':
        snowflake_import(args)

if __name__ == "__main__":
    main()

# parser_deploy.add_argument('--config-folder', type = str, default = '.', help = 'The folder to look in for the schemachange-config.yml file (the default is the current working directory)', required = False)
# parser_deploy.add_argument('-f', '--root-folder', type = str, help = 'The root folder for the database change scripts', required = False)
# parser_deploy.add_argument('-m', '--modules-folder', type = str, help = 'The modules folder for jinja macros and templates to be used across multiple scripts', required = False)
# parser_deploy.add_argument('-a', '--snowflake-account', type = str, help = 'The name of the snowflake account (e.g. xy12345.east-us-2.azure)', required = False)
# parser_deploy.add_argument('-u', '--snowflake-user', type = str, help = 'The name of the snowflake user', required = False)
# parser_deploy.add_argument('-r', '--snowflake-role', type = str, help = 'The name of the default role to use', required = False)
# parser_deploy.add_argument('-w', '--snowflake-warehouse', type = str, help = 'The name of the default warehouse to use. Can be overridden in the change scripts.', required = False)
# parser_deploy.add_argument('-d', '--snowflake-database', type = str, help = 'The name of the default database to use. Can be overridden in the change scripts.', required = False)
# parser_deploy.add_argument('-c', '--change-history-table', type = str, help = 'Used to override the default name of the change history table (the default is METADATA.SCHEMACHANGE.CHANGE_HISTORY)', required = False)
# parser_deploy.add_argument('--vars', type = json.loads, help = 'Define values for the variables to replaced in change scripts, given in JSON format (e.g. {"variable1": "value1", "variable2": "value2"})', required = False)
# parser_deploy.add_argument('--create-change-history-table', action='store_true', help = 'Create the change history schema and table, if they do not exist (the default is False)', required = False)
# parser_deploy.add_argument('-ac', '--autocommit', action='store_true', help = 'Enable autocommit feature for DML commands (the default is False)', required = False)
# parser_deploy.add_argument('-v','--verbose', action='store_true', help = 'Display verbose debugging details during execution (the default is False)', required = False)
# parser_deploy.add_argument('--dry-run', action='store_true', help = 'Run schemachange in dry run mode (the default is False)', required = False)
# parser_deploy.add_argument('--query-tag', type = str, help = 'The string to add to the Snowflake QUERY_TAG session value for each query executed', required = False)
# parser_deploy.add_argument('--oauth-config', type = json.loads, help = 'Define values for the variables to Make Oauth Token requests  (e.g. {"token-provider-url": "https//...", "token-request-payload": {"client_id": "GUID_xyz",...},... })', required = False)
# # TODO test CLI passing of args
# parser_render.add_argument('--config-folder', type = str, default = '.', help = 'The folder to look in for the schemachange-config.yml file (the default is the current working directory)', required = False)
# parser_render.add_argument('-f', '--root-folder', type = str, help = 'The root folder for the database change scripts', required = False)
# parser_render.add_argument('-m', '--modules-folder', type = str, help = 'The modules folder for jinja macros and templates to be used across multiple scripts', required = False)
# parser_render.add_argument('--vars', type = json.loads, help = 'Define values for the variables to replaced in change scripts, given in JSON format (e.g. {"variable1": "value1", "variable2": "value2"})', required = False)
# parser_render.add_argument('-v', '--verbose', action='store_true', help = 'Display verbose debugging details during execution (the default is False)', required = False)
# parser_render.add_argument('script', type = str, help = 'The script to render')
