import enum 

class HANDLE_OWNERSHIP_OPTION(enum.Enum):
    GRANT = 1
    ERROR = 2
