from configurator.configurator import configurator

def snowflake_deploy(args:dict):
    print('this is the deploy file')
    #my_configurator = configurator(args)
    #config = my_configurator.get_config()
    #print(config)
#if __name__ == "__main__":
#    main()

