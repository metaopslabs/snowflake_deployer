def snowflake_import(args:dict):
    print('this is import')

#argv=sys.argv   
#if __name__ == "__main__":
#    import()

